SIMPLE CHATTING SYSTEM - UPDATED

Database configuration:
Host: db01.dbhost.dev
Port: 5051
Database: db_454v7cyy3
Username: user_454v7cyy3
Password: p454v7cyy3

Login users:
1. kissa
2. mitta
3. sweeta
4. motvani
5. dumil

For this demo version, each username is also its password.
Example: username = kissa, password = kissa

The login servlet automatically creates the users table if it does not exist
and adds the five requested users when they are first used.
